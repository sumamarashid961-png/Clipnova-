// server.js — ClipNova API: uploads → background job queue → FFmpeg render → /exports/<id>.mp4
import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { verifyAuth, requireRole, requireActiveEntitlement, reserveCredit, refundCredit } from './authMiddleware.js';
import stripeRouter from './stripeRouter.js';
import { planGate, limitsFor, scriptForPlan } from './planGate.js';
import { uploadExport, signedExportUrl, deleteExport } from './firebaseAdmin.js';
import { sanitizeScript, isAllowedFormat, extForMime } from './security.js';
import { analyzeScript, fetchStockClips, generateVoiceover, resolveVoiceId } from './aiServices.js';
import { inspectMedia, maxSlotsFor, normalizeLogo, planBrollSlots, renderVideo } from './videoProcessor.js';
import { BRAND, log } from './brand.js';

/* ───────────────────────── config ───────────────────────── */

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const IS_PROD = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT || 4000);
const BASE_URL = process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`;
const UPLOAD_DIR = path.join(__dirname, 'tmp', 'uploads');
const WORK_DIR = path.join(__dirname, 'tmp', 'work');
const EXPORT_DIR = path.join(__dirname, 'public', 'exports');
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 500);
const HARD_MAX_SEC = 120; // product cap: 2 minutes
const CONCURRENCY = Number(process.env.RENDER_CONCURRENCY || 1);
const JOB_TTL_MS = Number(process.env.JOB_TTL_HOURS || 24) * 3_600_000;
const MUSIC_PATH = process.env.BACKGROUND_MUSIC_PATH
  ? path.resolve(__dirname, process.env.BACKGROUND_MUSIC_PATH)
  : null;

await Promise.all([UPLOAD_DIR, WORK_DIR, EXPORT_DIR].map((d) => fs.mkdir(d, { recursive: true })));

/* ───────────────────────── app + security middleware ───────────────────────── */

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', Number(process.env.TRUST_PROXY || 0)); // set to 1 behind nginx/Render/Fly

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } })); // allow <video> from your frontend
const allowedOrigins = (process.env.CORS_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean);
app.use(cors({
  origin: (origin, cb) => (!origin || allowedOrigins.includes(origin) ? cb(null, true) : cb(new Error('Origin not allowed'))),
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
// Stripe router MUST come before express.json(): the webhook needs the raw body.
app.use('/api/stripe', stripeRouter);
app.use(express.json({ limit: '100kb' }));

app.use(rateLimit({
  windowMs: 15 * 60_000,
  limit: Number(process.env.GLOBAL_RATE_LIMIT || 100),
  standardHeaders: 'draft-7',
  legacyHeaders: false,
}));
// Stricter limit on the expensive endpoint.
const generateLimiter = rateLimit({
  windowMs: 60 * 60_000,
  limit: Number(process.env.GENERATE_RATE_LIMIT || 5),
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Too many render requests. Please try again later.' },
});

// Finished videos. Filenames are random UUIDs (unguessable); forced download + nosniff.
app.use('/exports', express.static(EXPORT_DIR, {
  index: false,
  maxAge: '1h',
  setHeaders: (res) => {
    res.setHeader('Content-Disposition', 'attachment; filename="clipnova-video.mp4"');
    res.setHeader('X-Content-Type-Options', 'nosniff');
  },
}));

/* ───────────────────────── uploads (Multer) ───────────────────────── */

const VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime'];
const ALLOWED_TYPES = {
  baseVideo: VIDEO_TYPES,
  brollClips: VIDEO_TYPES,
  logo: ['image/png', 'image/svg+xml', 'image/jpeg', 'image/webp'],
};
const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    // Never use the client's filename — random name + sanitised extension.
    filename: (_req, file, cb) =>
      cb(null, randomUUID() + extForMime(file.mimetype)),
  }),
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 10 },
  fileFilter: (_req, file, cb) =>
    ALLOWED_TYPES[file.fieldname]?.includes(file.mimetype)
      ? cb(null, true)
      : cb(new Error(`Unsupported file for "${file.fieldname}"`)),
}).fields([
  { name: 'baseVideo', maxCount: 1 },
  { name: 'logo', maxCount: 1 },
  { name: 'brollClips', maxCount: 8 },
]);
const handleUpload = (req, res, next) =>
  upload(req, res, (err) => (err ? res.status(400).json({ error: err.message }) : next()));

const removeFiles = (files) => Promise.all(files.filter(Boolean).map((f) => fs.rm(f.path, { force: true })));

/* ───────────────────────── job queue (in-memory) ─────────────────────────
   Simple, dependency-free queue. For multiple server instances or restarts
   that must not lose jobs, swap this for BullMQ + Redis. */

const jobs = new Map();
const waiting = [];
let active = 0;

class UserError extends Error {} // safe to show to the client

function enqueue(job) {
  jobs.set(job.id, job);
  waiting.push(job);
  pump();
}
function pump() {
  while (active < CONCURRENCY && waiting.length) {
    const job = waiting.shift();
    active++;
    runJob(job).finally(() => { active--; pump(); });
  }
}
const setStage = (job, stage, progress) => { job.stage = stage; job.progress = Math.round(progress); };

// Housekeeping: drop old jobs + their exported files.
setInterval(async () => {
  const cutoff = Date.now() - JOB_TTL_MS;
  for (const [id, job] of jobs) {
    if (job.status !== 'queued' && job.status !== 'processing' && job.createdAt < cutoff) {
      jobs.delete(id);
      await fs.rm(path.join(EXPORT_DIR, `${id}.mp4`), { force: true });
      if (job.storagePath) await deleteExport(job.storagePath).catch(() => {});
    }
  }
}, 30 * 60_000).unref();

/* ───────────────────────── the pipeline ───────────────────────── */

async function runJob(job) {
  const { params, files, limits } = job.ctx;
  const work = path.join(WORK_DIR, job.id);
  try {
    job.status = 'processing';
    await fs.mkdir(work, { recursive: true });

    // 0. Inspect the real file (don't trust the MIME type) and cap duration.
    const baseInfo = await inspectMedia(files.base.path);
    if (!baseInfo.hasVideo || !isAllowedFormat(baseInfo.formatName)) {
      throw new UserError('Unsupported or invalid video file (use MP4, MOV or WebM).');
    }
    // Plan cap applied again here (defence in depth): free = 7 s, paid = 120 s.
    let totalSec = Math.min(params.maxDuration, HARD_MAX_SEC, limits.maxSec, baseInfo.duration);
    if (totalSec < 1) throw new UserError('The base video is too short.');

    // 1. AI voiceover first, because its length can shorten the final cut.
    let voicePath = null;
    if (params.audioPreference === 'ai_voice') {
      setStage(job, 'generating_voice', 5);
      voicePath = path.join(work, 'voice.mp3');
      await generateVoiceover({
        text: scriptForPlan(params.script, limits, 'voice'), // free: only what fits in 7 s
        voiceId: params.voiceId,
        outPath: voicePath,
      });
      const voice = await inspectMedia(voicePath);
      if (voice.duration > 0) totalSec = Math.min(totalSec, voice.duration + 1); // no dead air at the end
    }

    // 2. Script analysis (GPT-4o) + stock footage (Pexels/Pixabay).
    const items = [];
    const maxSlots = maxSlotsFor(totalSec, params.bRollDensity);
    if (params.autoBroll && params.script && maxSlots > 0) {
      setStage(job, 'transcribing', 15);
      const scenes = await analyzeScript({
        script: scriptForPlan(params.script, limits, 'analysis'),
        durationSec: totalSec,
        maxScenes: maxSlots,
      });
      setStage(job, 'fetching_broll', 25);
      const stock = await fetchStockClips(scenes, work);
      items.push(...stock.map((s) => ({ clipPath: s.clipPath, startHint: s.startSec })));
    }
    // The user's own clips always get priority placement.
    for (const clip of files.broll) {
      const info = await inspectMedia(clip.path).catch(() => null);
      if (info?.hasVideo && isAllowedFormat(info.formatName)) items.push({ clipPath: clip.path, priority: true });
    }
    const slots = planBrollSlots({ totalSec, density: params.bRollDensity, items });

    // 3. Logo → sanitised PNG.
    let logo;
    if (files.logo) {
      const logoPng = await normalizeLogo(files.logo.path, path.join(work, 'logo.png'));
      logo = { path: logoPng, position: params.logoPosition, opacity: params.logoOpacity, scalePct: params.logoScale };
    }

    // 4. Render.
    setStage(job, logo ? 'overlaying_logo' : 'exporting', 50);
    const outPath = path.join(EXPORT_DIR, `${job.id}.mp4`);
    await renderVideo({
      baseVideo: files.base.path,
      outputPath: outPath,
      totalSec,
      resolution: params.resolution,
      limits: { maxSec: limits.maxSec, watermark: limits.watermark }, // free → -t 7 + watermark filter
      slots,
      logo,
      audio: {
        mode: params.audioPreference,
        hasBaseAudio: baseInfo.hasAudio,
        voicePath,
        musicPath: MUSIC_PATH && (await fs.stat(MUSIC_PATH).then(() => MUSIC_PATH, () => null)),
      },
      onProgress: (p) => setStage(job, p > 10 ? 'exporting' : job.stage, 50 + p * 0.49),
    });

    if (process.env.FIREBASE_STORAGE_BUCKET) {
      job.storagePath = await uploadExport(outPath, job.uid, job.id); // private bucket
      await fs.rm(outPath, { force: true });                           // local copy deleted right away
    } else {
      job.outputUrl = `${BASE_URL}/exports/${job.id}.mp4`;            // local-dev fallback only
    }
    job.durationSec = Math.round(totalSec);
    job.watermarked = limits.watermark;
    job.status = 'completed';
    setStage(job, 'done', 100);
  } catch (err) {
    log.error(`[job ${job.id}] failed:`, err);
    job.status = 'failed';
    job.error = err instanceof UserError ? err.message : 'Rendering failed. Please try again.';
    if (job.charged) { // failed renders don't cost the user a credit
      job.charged = false;
      await refundCredit(job.uid, job.chargedDay).catch((e) => log.error('credit refund failed:', e));
    }
  } finally {
    // Never keep user uploads or intermediate files around.
    await Promise.all([
      fs.rm(work, { recursive: true, force: true }),
      removeFiles([files.base, files.logo, ...files.broll]),
    ]);
    delete job.ctx;
  }
}

/* ───────────────────────── routes ───────────────────────── */

const pick = (value, allowed, fallback) => {
  const v = String(value ?? '').trim().toLowerCase().replace(/[\s_]+/g, '-');
  return allowed.includes(v) ? v : fallback;
};
const num = (value, min, max, fallback) => {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};

app.get('/health', (_req, res) => res.json({ ok: true, app: BRAND.name, tagline: BRAND.tagline, queued: waiting.length, active }));

// Current user's role / plan / credits (also creates their profile on first login).
app.get('/api/me', verifyAuth, (req, res) => {
  const { uid, email, role, plan, freeRemaining, anonymous } = req.user;
  res.json({ uid, email, role, plan, anonymous, freeRemaining, limits: limitsFor(req.user) });
});

// Example admin-only route (RBAC).
app.get('/api/admin/stats', verifyAuth, requireRole('admin'), (_req, res) =>
  res.json({ jobsInMemory: jobs.size, queued: waiting.length, active }));

/**
 * POST /api/generate-video  (multipart/form-data)
 *  files:  baseVideo (1, required) · logo (0-1) · brollClips (0-8)
 *  fields: script | topic · audioPreference (original|ai_voice) · voiceId
 *          logoPosition · logoOpacity (10-100) · logoScale (5-40, % of video width)
 *          bRollDensity (low|balanced|high) · autoBroll (true|false)
 *          maxDuration (5-120 s) · resolution (1080p|4k)
 */
app.post('/api/generate-video', generateLimiter, verifyAuth, requireActiveEntitlement, handleUpload, planGate, async (req, res) => {
  const files = { base: req.files?.baseVideo?.[0], logo: req.files?.logo?.[0], broll: req.files?.brollClips ?? [] };
  const reject = async (status, error, code) => {
    await removeFiles([files.base, files.logo, ...files.broll]);
    return res.status(status).json({ error, code });
  };

  if (!files.base) return reject(400, 'baseVideo is required.');
  if (files.logo && files.logo.size > 5 * 1024 * 1024) return reject(400, 'Logo must be under 5 MB.');

  const params = {
    script: sanitizeScript(req.body.script ?? req.body.topic),
    audioPreference: pick(req.body.audioPreference, ['original', 'ai_voice'], 'original').replace('-', '_'),
    voiceId: req.body.voiceId,
    logoPosition: pick(req.body.logoPosition, ['top-left', 'top-right', 'bottom-left', 'bottom-right'], 'top-right'),
    logoOpacity: num(req.body.logoOpacity, 10, 100, 80) / 100,
    logoScale: num(req.body.logoScale, 5, 40, 15),
    bRollDensity: pick(req.body.bRollDensity, ['low', 'balanced', 'high'], 'balanced'),
    autoBroll: String(req.body.autoBroll) !== 'false',
    // Server-decided cap: free users can never get more than 7 s, whatever the client sends.
    maxDuration: Math.min(num(req.body.maxDuration, 5, HARD_MAX_SEC, 60), req.limits.maxSec),
    resolution: pick(req.body.resolution, ['1080p', '4k'], '1080p'),
  };

  // (4K / >7 s / watermark-removal for free users were already rejected with 402 by planGate.)

  if (params.audioPreference === 'ai_voice') {
    if (!params.script) return reject(400, 'A script is required for AI voiceover.');
    if (!process.env.ELEVENLABS_API_KEY) return reject(503, 'AI voiceover is not available right now.');
    try { params.voiceId = resolveVoiceId(params.voiceId); } catch (e) { return reject(400, e.message); }
  }

  // One render at a time per user (cheap abuse / cost control).
  for (const j of jobs.values()) {
    if (j.uid === req.user.uid && (j.status === 'queued' || j.status === 'processing')) {
      return reject(429, 'You already have a render in progress.');
    }
  }

  // Atomically reserve a credit (free users) / confirm subscription (paid). Refunded if the job fails.
  const reservation = await reserveCredit(req.user);
  if (!reservation.ok) return reject(429, "You've reached today's free limit. Upgrade for unlimited renders.", 'DAILY_LIMIT');


  const job = {
    id: randomUUID(), uid: req.user.uid, status: 'queued', stage: 'queued', progress: 0,
    createdAt: Date.now(), charged: reservation.charged, chargedDay: reservation.day,
    ctx: { params, files, limits: req.limits },
  };
  enqueue(job);
  res.status(202).json({ jobId: job.id, statusUrl: `/api/jobs/${job.id}` });
});

/** GET /api/jobs/:id — poll for progress (frontend: every 1-2 s). */
app.get('/api/jobs/:id', verifyAuth, async (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job || job.uid !== req.user.uid) return res.status(404).json({ error: 'Job not found' });
  res.json({
    id: job.id,
    status: job.status,       // queued | processing | completed | failed
    stage: job.stage,         // generating_voice | transcribing | fetching_broll | overlaying_logo | exporting | done
    progress: job.progress,   // 0-100
    queuePosition: job.status === 'queued' ? waiting.indexOf(job) + 1 : 0,
    // Private storage: a fresh 60-minute signed URL on every poll.
    outputUrl: job.storagePath ? await signedExportUrl(job.storagePath).catch(() => undefined) : job.outputUrl,
    durationSec: job.durationSec,
    watermarked: job.watermarked, // frontend shows "Remove watermark" upsell when true
    error: job.error,
  });
});

// Central error handler (never leak stack traces).
app.use((err, _req, res, _next) => {
  log.error(err);
  res.status(err.message === 'Origin not allowed' ? 403 : 500).json({ error: 'Request failed' });
});

/* ───────────────────────── start / shutdown ───────────────────────── */

const server = app.listen(PORT, () => log.info(`API listening on :${PORT}`));
for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => server.close(() => process.exit(0)));
}
