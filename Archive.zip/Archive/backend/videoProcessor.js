// videoProcessor.js — FFmpeg editing pipeline (pure FFmpeg; no Python/MoviePy needed).
//
// Strategy: ONE ffmpeg pass with a filter graph.
//   • Base video is trimmed to the target length and normalised (scale/pad/fps).
//   • B-roll clips are *cutaways overlaid* on the base at planned timestamps, so the
//     base audio / voiceover keeps playing and audio stays perfectly in sync.
//   • Logo is overlaid last (corner, opacity, scale).
//   • Audio = original track  OR  ElevenLabs voice + ducked background music.
// Requires FFmpeg >= 4.4 (uses amix=normalize=0).
import ffmpeg from 'fluent-ffmpeg';
import sharp from 'sharp';
import fsSync from 'node:fs';
import { WATERMARK_TEXT } from './planGate.js';

if (process.env.FFMPEG_PATH) ffmpeg.setFfmpegPath(process.env.FFMPEG_PATH);
if (process.env.FFPROBE_PATH) ffmpeg.setFfprobePath(process.env.FFPROBE_PATH);

const RESOLUTIONS = { '1080p': [1920, 1080], '4k': [3840, 2160] };
const DENSITY = {            // every = seconds between cutaways, len = cutaway length
  low:      { every: 20, len: 3 },
  balanced: { every: 12, len: 4 },
  high:     { every: 7,  len: 4 },
};
// ffmpeg may only read local files — blocks http/tcp/concat tricks hidden inside uploads.
const SAFE_IN = ['-protocol_whitelist', 'file'];
const MIN_START = 3;  // keep the opening on camera
const OUT_PAD = 2;    // ...and the ending
const GAP = 3;        // min seconds between cutaways

/* ───────────────────────── probing ───────────────────────── */

const probe = (file) =>
  new Promise((resolve, reject) => ffmpeg.ffprobe(file, SAFE_IN, (err, data) => (err ? reject(err) : resolve(data))));

/** Inspect the real file contents (client-supplied MIME types can't be trusted). */
export async function inspectMedia(file) {
  const data = await probe(file);
  const video = data.streams.find((s) => s.codec_type === 'video');
  const audio = data.streams.find((s) => s.codec_type === 'audio');
  return {
    formatName: data.format?.format_name ?? '',
    duration: Number(data.format?.duration) || 0,
    hasVideo: Boolean(video),
    hasAudio: Boolean(audio),
    width: video?.width,
    height: video?.height,
  };
}

/** Validate + convert any uploaded logo (PNG/JPG/WebP/SVG) to a safe PNG. */
export async function normalizeLogo(inputPath, outPath) {
  await sharp(inputPath, { density: 300 })
    .resize({ width: 1200, withoutEnlargement: true })
    .png()
    .toFile(outPath);
  return outPath;
}

/* ───────────────────── B-roll planning ───────────────────── */

/** Timing rules by video length. Short clips (e.g. the 7 s free preview) get ONE tight cutaway. */
function profileFor(totalSec, density) {
  const d = DENSITY[density] ?? DENSITY.balanced;
  if (totalSec < 15) {
    return {
      len: Math.min(2.5, Math.max(1.5, totalSec * 0.35)),
      minStart: 1.5, outPad: 1, gap: 1, every: totalSec,
      limit: totalSec >= 4 ? 1 : 0,
    };
  }
  return {
    len: d.len, minStart: MIN_START, outPad: OUT_PAD, gap: GAP, every: d.every,
    limit: Math.max(1, Math.floor((totalSec - MIN_START - OUT_PAD) / d.every)),
  };
}

export const maxSlotsFor = (totalSec, density) => profileFor(totalSec, density).limit;

/**
 * Turn clips into non-overlapping timeline slots.
 * items: [{ clipPath, startHint?, priority? }]  (priority = user's own clips, placed first)
 * Slot timing is enforced here in code — GPT's timestamps are only hints.
 */
export function planBrollSlots({ totalSec, density, items }) {
  const { len, minStart, outPad, gap, every, limit } = profileFor(totalSec, density);
  const latestStart = totalSec - outPad - len;
  const slots = [];

  const fits = (s) =>
    s >= minStart && s <= latestStart &&
    slots.every((x) => s >= x.end + gap || s + len + gap <= x.start);

  const place = (item, hint) => {
    if (slots.length >= limit) return;
    const first = Math.min(Math.max(hint, minStart), latestStart);
    for (let s = first; s <= Math.min(first + 6, latestStart); s += 0.5) { // nudge forward if crowded
      if (fits(s)) {
        slots.push({ clipPath: item.clipPath, start: +s.toFixed(2), end: +(s + len).toFixed(2) });
        return;
      }
    }
  };

  items.filter((i) => i.priority).forEach((it, i) => place(it, minStart + i * every));
  items
    .filter((i) => !i.priority)
    .sort((a, b) => (a.startHint ?? Infinity) - (b.startHint ?? Infinity))
    .forEach((it, i) => place(it, it.startHint ?? minStart + i * every));

  return slots.sort((a, b) => a.start - b.start);
}

/* ───────────────────────── rendering ───────────────────────── */

const timemarkToSec = (tm = '00:00:00') => {
  const [h, m, s] = tm.split(':').map(Number);
  return h * 3600 + m * 60 + s;
};

/**
 * Render the final MP4.
 * @param {object} o
 * @param {string} o.baseVideo
 * @param {string} o.outputPath
 * @param {number} o.totalSec                    final duration (already capped)
 * @param {'1080p'|'4k'} [o.resolution]
 * @param {{clipPath:string,start:number,end:number}[]} [o.slots]
 * @param {{path:string,position:string,opacity:number,scalePct:number}} [o.logo]
 *        position: top-left|top-right|bottom-left|bottom-right · opacity 0-1 · scalePct = % of video width
 * @param {{mode:'original'|'ai_voice',hasBaseAudio:boolean,voicePath?:string,musicPath?:string}} o.audio
 * @param {(percent:number)=>void} [o.onProgress]
 * @param {{maxSec:number,watermark:boolean}} [o.limits]  plan limits — maxSec is a HARD cap (free = 7), watermark burns the text in
 */
export function renderVideo({
  baseVideo, outputPath, totalSec, resolution = '1080p', slots = [], logo, audio, onProgress,
  limits = { maxSec: 120, watermark: false },
}) {
  const [W, H] = RESOLUTIONS[resolution] ?? RESOLUTIONS['1080p'];
  // Last line of defence: whatever the caller asked for, a free render can never exceed its cap.
  // (The same value is applied as `-t` on the output below.)
  totalSec = Math.min(totalSec, limits.maxSec);
  const T = totalSec.toFixed(3);
  const cmd = ffmpeg();
  const filters = [];
  let idx = 0;

  // Common normalisation so every source looks identical to the filter graph.
  const norm =
    `scale=${W}:${H}:force_original_aspect_ratio=decrease,` +
    `pad=${W}:${H}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,fps=30,format=yuv420p`;

  /* ── video: base ── */
  cmd.input(baseVideo).inputOptions(SAFE_IN); idx++;
  filters.push(`[0:v]trim=duration=${T},setpts=PTS-STARTPTS,${norm}[v0]`);
  let vLabel = 'v0';

  /* ── video: B-roll cutaways (overlay enabled only inside each window) ── */
  slots.forEach((s, i) => {
    cmd.input(s.clipPath).inputOptions([...SAFE_IN, '-stream_loop', '-1']); // loop clips shorter than the slot
    const d = (s.end - s.start).toFixed(3);
    filters.push(`[${idx}:v]trim=duration=${d},setpts=PTS-STARTPTS+${s.start}/TB,${norm}[b${i}]`);
    filters.push(
      `[${vLabel}][b${i}]overlay=eof_action=pass:enable='between(t,${s.start},${s.end})'[v${i + 1}]`,
    );
    vLabel = `v${i + 1}`;
    idx++;
  });

  /* ── video: brand logo ── */
  if (logo) {
    cmd.input(logo.path).inputOptions([...SAFE_IN, '-loop', '1']); // still image → endless stream
    const lw = Math.round((W * Math.min(Math.max(logo.scalePct, 5), 40)) / 100 / 2) * 2;
    const m = Math.round(W * 0.02); // edge margin
    const pos = {
      'top-left':     `x=${m}:y=${m}`,
      'top-right':    `x=main_w-overlay_w-${m}:y=${m}`,
      'bottom-left':  `x=${m}:y=main_h-overlay_h-${m}`,
      'bottom-right': `x=main_w-overlay_w-${m}:y=main_h-overlay_h-${m}`,
    }[logo.position] ?? `x=main_w-overlay_w-${m}:y=${m}`;
    filters.push(`[${idx}:v]format=rgba,scale=${lw}:-1,colorchannelmixer=aa=${logo.opacity.toFixed(2)}[lg]`);
    filters.push(`[${vLabel}][lg]overlay=${pos}:format=auto:shortest=1[vout]`);
    vLabel = 'vout';
    idx++;
  }

  /* ── video: freemium watermark (always the top-most layer) ── */
  if (limits.watermark) {
    // Text comes from our own env var; strip anything that could break out of the filter syntax.
    const text = WATERMARK_TEXT.replace(/[^\p{L}\p{N} .,@_-]/gu, '');
    const font = process.env.WATERMARK_FONT || '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';
    const fontOpt = fsSync.existsSync(font) ? `fontfile='${font}':` : '';
    const size = Math.round(H * 0.03);      // ≈32 px on 1080p — subtle but readable
    const margin = Math.round(H * 0.04);
    filters.push(
      `[${vLabel}]drawtext=${fontOpt}text='${text}':fontsize=${size}:fontcolor=white@0.6:` +
      `shadowcolor=black@0.5:shadowx=2:shadowy=2:x=(w-text_w)/2:y=h-text_h-${margin}[vwm]`,
    );
    vLabel = 'vwm';
  }

  /* ── audio ── */
  if (audio.mode === 'ai_voice' && audio.voicePath) {
    // Original audio is dropped entirely (never mapped). Voice (+ optional ducked music).
    cmd.input(audio.voicePath).inputOptions(SAFE_IN);
    const vi = idx++;
    const voiceChain =
      `[${vi}:a]aresample=44100,aformat=channel_layouts=stereo,apad,atrim=duration=${T},asetpts=PTS-STARTPTS`;
    if (audio.musicPath) {
      cmd.input(audio.musicPath).inputOptions([...SAFE_IN, '-stream_loop', '-1']);
      const mi = idx++;
      filters.push(`${voiceChain},asplit=2[vo][vs]`);
      filters.push(
        `[${mi}:a]aresample=44100,aformat=channel_layouts=stereo,volume=0.20,atrim=duration=${T},asetpts=PTS-STARTPTS[mus]`,
      );
      // Music "ducks" whenever the narrator speaks.
      filters.push('[mus][vs]sidechaincompress=threshold=0.04:ratio=10:attack=20:release=500[duck]');
      filters.push('[vo][duck]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]');
    } else {
      filters.push(`${voiceChain}[aout]`);
    }
  } else if (audio.hasBaseAudio) {
    filters.push(`[0:a]atrim=duration=${T},asetpts=PTS-STARTPTS[aout]`);
  } else {
    filters.push(`anullsrc=r=44100:cl=stereo,atrim=duration=${T}[aout]`); // silent track
  }

  /* ── encode ── */
  cmd
    .complexFilter(filters, [vLabel, 'aout'])
    .outputOptions([
      '-c:v libx264',
      `-preset ${process.env.FFMPEG_PRESET || 'medium'}`,
      `-crf ${process.env.FFMPEG_CRF || 18}`,
      '-profile:v high',
      '-pix_fmt yuv420p',
      '-r 30',
      '-c:a aac',
      '-b:a 192k',
      '-ar 44100',
      '-movflags +faststart', // web-streamable MP4
      `-t ${T}`,
    ]);

  return new Promise((resolve, reject) => {
    const timeoutMs = Number(process.env.RENDER_TIMEOUT_MIN || 15) * 60_000;
    const timer = setTimeout(() => {
      cmd.kill('SIGKILL');
      reject(new Error('FFmpeg render timed out'));
    }, timeoutMs);

    cmd
      .on('progress', (p) => onProgress?.(Math.min(99, (timemarkToSec(p.timemark) / totalSec) * 100)))
      .on('error', (err, _stdout, stderr) => {
        clearTimeout(timer);
        reject(new Error(`FFmpeg failed: ${err.message}\n${String(stderr).slice(-1500)}`));
      })
      .on('end', () => {
        clearTimeout(timer);
        resolve(outputPath);
      })
      .save(outputPath);
  });
}
