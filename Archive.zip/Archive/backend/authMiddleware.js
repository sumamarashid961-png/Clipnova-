// authMiddleware.js — Firebase JWT verification, role-based access control, and
// "may this user render?" checks (active subscription OR remaining free credits).
//
// Firestore document  users/{uid}  (written ONLY by this server / Stripe webhook):
//   email, plan: 'free'|'pro'|'agency', subscriptionStatus, subscriptionId,
//   stripeCustomerId, currentPeriodEnd (ms), freeDay, freeUsedToday, banned?, createdAt
//
// Roles (req.user.role):
//   admin → Firebase custom claim { role: 'admin' } (set with scripts/set-admin.js)
//   paid  → active/trialing Pro or Agency subscription
//   free  → everyone else (limited by freeCredits)
import { auth, db, enabled, FieldValue } from './firebaseAdmin.js';
import { log } from './brand.js';

const IS_PROD = process.env.NODE_ENV === 'production';
// Local-dev escape hatch only. Impossible to enable in production.
const DEV_BYPASS = !IS_PROD && process.env.REQUIRE_AUTH === 'false';
// Free users are not capped on *features* (7 s + watermark does that) but on volume, to protect your API bill.
const FREE_DAILY_RENDERS = Number(process.env.FREE_DAILY_RENDERS ?? 5);
const todayKey = () => new Date().toISOString().slice(0, 10);
const PAID_PLANS = new Set(['pro', 'agency']);
const ACTIVE_STATUSES = new Set(['active', 'trialing']);
const PERIOD_GRACE_MS = 2 * 24 * 3_600_000; // tolerate a late renewal webhook

const users = () => db.collection('users');

/** Load the user's profile, creating it (with free credits) on first sight. */
export async function getOrCreateUser(uid, email) {
  const ref = users().doc(uid);
  return db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (snap.exists) return snap.data();
    const fresh = {
      email: email ?? null,
      plan: 'free',
      subscriptionStatus: 'none',
      freeDay: null,
      freeUsedToday: 0,
      createdAt: FieldValue.serverTimestamp(),
    };
    tx.create(ref, fresh);
    return { ...fresh, createdAt: null };
  });
}

/** Is the paid plan genuinely active right now? Status comes from Stripe webhooks. */
export function entitlementOf(profile) {
  const paid =
    PAID_PLANS.has(profile.plan) &&
    ACTIVE_STATUSES.has(profile.subscriptionStatus) &&
    (!profile.currentPeriodEnd || profile.currentPeriodEnd + PERIOD_GRACE_MS > Date.now());
  return { paid, effectivePlan: paid ? profile.plan : 'free' };
}

/* ───────────────────────── 1. authenticate ───────────────────────── */

export async function verifyAuth(req, res, next) {
  if (DEV_BYPASS) {
    req.user = { uid: 'dev-user', email: 'dev@localhost', role: 'admin', plan: 'agency', paid: true, anonymous: false, freeRemaining: 999 };
    return next();
  }
  if (!enabled) return res.status(500).json({ error: 'Authentication is not configured.' });

  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Please sign in.', code: 'UNAUTHENTICATED' });

  let decoded;
  try {
    decoded = await auth.verifyIdToken(token, true); // true = also reject revoked sessions
  } catch {
    return res.status(401).json({ error: 'Session expired. Please sign in again.', code: 'UNAUTHENTICATED' });
  }
  // Guests use Firebase *anonymous* auth: a real, verifiable uid without any signup friction.
  const isAnon = decoded.firebase?.sign_in_provider === 'anonymous';
  if (process.env.REQUIRE_VERIFIED_EMAIL === 'true' && !isAnon && !decoded.email_verified) {
    return res.status(403).json({ error: 'Please verify your email first.', code: 'EMAIL_NOT_VERIFIED' });
  }

  try {
    const profile = await getOrCreateUser(decoded.uid, decoded.email);
    if (profile.banned) return res.status(403).json({ error: 'Account suspended.', code: 'BANNED' });
    const { paid, effectivePlan } = entitlementOf(profile);
    req.user = {
      uid: decoded.uid,
      email: decoded.email ?? null,
      role: decoded.role === 'admin' ? 'admin' : paid ? 'paid' : 'free',
      plan: effectivePlan,
      paid,
      anonymous: isAnon,
      freeRemaining: Math.max(0, FREE_DAILY_RENDERS - (profile.freeDay === todayKey() ? profile.freeUsedToday ?? 0 : 0)),
    };
    next();
  } catch (err) {
    log.error('profile load failed:', err);
    res.status(503).json({ error: 'Service temporarily unavailable.' });
  }
}

/* ───────────────────────── 2. authorise ───────────────────────── */

/** requireRole('paid') lets paid users AND admins through; requireRole('admin') admins only. */
export const requireRole = (...roles) => (req, res, next) =>
  req.user && (req.user.role === 'admin' || roles.includes(req.user.role))
    ? next()
    : res.status(403).json({ error: 'Forbidden.', code: 'FORBIDDEN' });

/** Cheap pre-check (before accepting a big upload): paid/admin always pass; free users have a daily volume cap. */
export function requireActiveEntitlement(req, res, next) {
  const u = req.user;
  if (u.role === 'admin' || u.paid || u.freeRemaining > 0) return next();
  res.status(429).json({
    error: "You've reached today's free limit. Upgrade for unlimited renders.",
    code: 'DAILY_LIMIT',
  });
}

/* ───────────────────────── 3. credits ───────────────────────── */

/**
 * Atomically reserve one render. Paid users / admins render freely; free users consume one of
 * their FREE_DAILY_RENDERS inside a Firestore transaction (no double-spend, resets each UTC day).
 * @returns {Promise<{ok: boolean, charged: boolean, day?: string}>}
 */
export async function reserveCredit(user) {
  if (DEV_BYPASS || user.role === 'admin' || user.paid) return { ok: true, charged: false };
  const ref = users().doc(user.uid);
  const day = todayKey();
  return db.runTransaction(async (tx) => {
    const data = (await tx.get(ref)).data() ?? {};
    const used = data.freeDay === day ? data.freeUsedToday ?? 0 : 0;
    if (used >= FREE_DAILY_RENDERS) return { ok: false, charged: false };
    tx.update(ref, { freeDay: day, freeUsedToday: used + 1 });
    return { ok: true, charged: true, day };
  });
}

/** Give the render back when a job fails (only if the counter still belongs to the same day). */
export async function refundCredit(uid, day) {
  if (!db || !day) return;
  const ref = users().doc(uid);
  await db.runTransaction(async (tx) => {
    const data = (await tx.get(ref)).data() ?? {};
    if (data.freeDay === day && (data.freeUsedToday ?? 0) > 0) tx.update(ref, { freeUsedToday: data.freeUsedToday - 1 });
  });
}
