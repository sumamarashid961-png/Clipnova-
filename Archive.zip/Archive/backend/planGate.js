// planGate.js — the Freemium "7-second + watermark" gate.
// SERVER-SIDE is the source of truth: the client only mirrors these rules to show the paywall early.
//
//   Free (incl. anonymous guests):  ≤ 7 s, watermark burned in, 1080p, downloads allowed
//   Paid (Pro / Agency) & admins:   ≤ 120 s, no watermark, 1080p or 4K
import fs from 'node:fs/promises';
import { BRAND } from './brand.js';

export const FREE_MAX_SEC = Number(process.env.FREE_MAX_SEC ?? 7);
export const PAID_MAX_SEC = 120;
export const WATERMARK_TEXT = process.env.WATERMARK_TEXT || BRAND.watermark;

const FREE_VOICE_CHARS = Number(process.env.FREE_VOICE_CHARS ?? 160); // ≈ 7 s of narration (caps ElevenLabs cost)
const FREE_ANALYSIS_CHARS = 600;                                       // caps OpenAI cost

/** What this user is allowed to render. Derived ONLY from server-verified state (req.user). */
export function limitsFor(user) {
  const paid = user.role === 'admin' || user.paid === true;
  return paid
    ? { paid: true, maxSec: PAID_MAX_SEC, watermark: false, allow4k: true }
    : { paid: false, maxSec: FREE_MAX_SEC, watermark: true, allow4k: false };
}

/** Free users only pay (us!) for the part of the script that fits in their 7 seconds. */
export function scriptForPlan(script, limits, purpose) {
  if (limits.paid) return script;
  const max = purpose === 'voice' ? FREE_VOICE_CHARS : FREE_ANALYSIS_CHARS;
  return script.length <= max ? script : script.slice(0, max).replace(/\s+\S*$/, '');
}

/**
 * Runs AFTER the multipart upload is parsed (it needs the form fields).
 *  • sets req.limits for the rest of the request
 *  • if a free user explicitly asks for a paid feature → 402 PAYWALL_REQUIRED (frontend opens the Stripe modal)
 *    and the just-uploaded temp files are deleted.
 * Quietly clamps everything else (e.g. a missing maxDuration), so the 7 s cap can never be exceeded.
 */
export async function planGate(req, res, next) {
  const limits = limitsFor(req.user);
  req.limits = limits;

  const reasons = [];
  if (!limits.paid) {
    if (Number(req.body.maxDuration) > limits.maxSec) reasons.push('duration');
    if (String(req.body.resolution).toLowerCase() === '4k') reasons.push('resolution');
    if (String(req.body.removeWatermark) === 'true') reasons.push('watermark');
  }
  if (!reasons.length) return next();

  await Promise.all(Object.values(req.files ?? {}).flat().map((f) => fs.rm(f.path, { force: true })));
  res.status(402).json({
    error: 'Upgrade to unlock full-length, watermark-free videos.',
    code: 'PAYWALL_REQUIRED',
    reasons,                       // e.g. ['duration', 'watermark']
    freeMaxSec: FREE_MAX_SEC,
    proMaxSec: PAID_MAX_SEC,
  });
}
