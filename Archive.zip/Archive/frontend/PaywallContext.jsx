// Paywall: call `const openPaywall = usePaywall(); openPaywall('duration')` from anywhere.
// Reasons: 'duration' | 'watermark' | 'resolution' | 'daily'
import { createContext, useCallback, useContext, useState } from 'react';
import { EmailAuthProvider, linkWithCredential } from 'firebase/auth';
import { auth } from './firebase.js';
import { useAuth } from './AuthContext.jsx';
import { startCheckout } from './api.js';

const Ctx = createContext(() => {});
export const usePaywall = () => useContext(Ctx);

const HEADLINE = {
  duration: 'Your free preview is limited to 7 seconds.',
  watermark: 'Free videos carry a "Created with ClipNova Free" watermark.',
  resolution: '4K export is a Pro feature.',
  daily: "You've used today's free renders.",
};
const BENEFITS = [
  'Full-length videos up to 2 minutes',
  'Zero watermark — your brand only',
  '1080p and 4K export',
  'Unlimited renders & priority AI voices',
];
const ERRORS = {
  'auth/email-already-in-use': 'That email already has an account — sign in instead.',
  'auth/credential-already-in-use': 'That email already has an account — sign in instead.',
  'auth/weak-password': 'Password must be at least 8 characters.',
  'auth/invalid-email': 'Please enter a valid email.',
};

export function PaywallProvider({ children }) {
  const [reason, setReason] = useState(null);
  const open = useCallback((r) => setReason(r || 'duration'), []);
  return (
    <Ctx.Provider value={open}>
      {children}
      {reason && <PaywallModal reason={reason} onClose={() => setReason(null)} />}
    </Ctx.Provider>
  );
}

function PaywallModal({ reason, onClose }) {
  const { isAnonymous } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function unlock(e) {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      if (auth.currentUser?.isAnonymous) {
        // Upgrade the guest IN PLACE (same uid), so their usage and the subscription stay on one account.
        await linkWithCredential(auth.currentUser, EmailAuthProvider.credential(email, password));
        await auth.currentUser.getIdToken(true); // refresh so the token now carries the email
      }
      await startCheckout('pro'); // redirects to Stripe Checkout
    } catch (err) {
      setError(ERRORS[err.code] ?? err.message ?? 'Something went wrong. Please try again.');
      setBusy(false);
    }
  }

  const field = 'w-full rounded-lg border border-slate-600 bg-slate-900/70 px-3 py-2.5 text-sm outline-none focus:border-indigo-400';

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4 backdrop-blur-sm" onClick={onClose}>
      <form
        onSubmit={unlock}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md space-y-4 rounded-2xl border border-indigo-400/30 bg-slate-900 p-6 shadow-2xl shadow-indigo-500/20"
      >
        <button type="button" onClick={onClose} aria-label="Close" className="float-right text-slate-500 hover:text-slate-200">✕</button>
        <p className="text-xs font-semibold uppercase tracking-wider text-indigo-300">{HEADLINE[reason]}</p>
        <h2 className="text-2xl font-bold leading-tight text-white">Unlock Full 2-Min Video &amp; Remove Watermark</h2>

        <ul className="space-y-2 text-sm text-slate-300">
          {BENEFITS.map((b) => <li key={b}><span className="mr-2 text-emerald-400">✔</span>{b}</li>)}
        </ul>

        <div className="rounded-xl bg-slate-800/70 p-4 text-center">
          <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-indigo-300">ClipNova Pro</p>
          <span className="text-4xl font-bold text-white">$19</span>
          <span className="text-slate-400"> / month</span>
          <p className="mt-1 text-xs text-slate-400">Cancel anytime · Secure checkout by Stripe</p>
        </div>

        {isAnonymous && (
          <div className="space-y-2">
            <p className="text-xs text-slate-400">Create your account so your subscription is saved:</p>
            <input className={field} type="email" placeholder="Email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <input className={field} type="password" placeholder="Password (8+ characters)" required minLength={8} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
        )}
        {error && <p className="text-sm text-red-300">{error} {error.includes('sign in') && <a className="underline" href="/login">Sign in</a>}</p>}

        <button disabled={busy} className="w-full rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 py-3 font-bold text-white disabled:opacity-60">
          {busy ? 'Opening secure checkout…' : 'Unlock Full Video — $19/mo'}
        </button>
        <button type="button" onClick={onClose} className="w-full text-sm text-slate-500 hover:text-slate-300">
          Maybe later — keep the free 7-second preview
        </button>
      </form>
    </div>
  );
}
