import { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, signInAnonymously, signOut } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from './firebase.js';
import { fetchMe } from './api.js';

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

// Mirrors the server's rules (planGate.js) so the UI can show the paywall instantly.
// The backend re-checks everything — this is UX, not security.
const FREE = { maxSec: 7, watermark: true, allow4k: false };
const PAID = { maxSec: 120, watermark: false, allow4k: true };

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);       // Firebase user — a *guest* (anonymous) until they register
  const [profile, setProfile] = useState(null); // live Firestore doc: plan, subscriptionStatus, ...
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(
    () =>
      onAuthStateChanged(auth, async (u) => {
        if (!u) {
          // Nobody signed in → silently create a guest account. No login wall for the free 7-second tier.
          setUser(null); setProfile(null); setIsAdmin(false);
          signInAnonymously(auth).catch((e) => { console.error(e); setLoading(false); });
          return;
        }
        setUser(u);
        const token = await u.getIdTokenResult();
        setIsAdmin(token.claims.role === 'admin');
        setLoading(false);
        fetchMe().catch(() => {}); // creates the Firestore profile on first visit
      }),
    [],
  );

  // Real-time plan updates: the badge flips to Pro seconds after Stripe's webhook fires.
  useEffect(() => {
    if (!user) return undefined;
    return onSnapshot(doc(db, 'users', user.uid), (snap) => setProfile(snap.data() ?? null));
  }, [user]);

  const paid =
    isAdmin ||
    (['pro', 'agency'].includes(profile?.plan) && ['active', 'trialing'].includes(profile?.subscriptionStatus));

  return (
    <Ctx.Provider
      value={{
        user, profile, isAdmin, paid, loading,
        limits: paid ? PAID : FREE,
        isAnonymous: Boolean(user?.isAnonymous),
        logout: () => signOut(auth),
      }}
    >
      {children}
    </Ctx.Provider>
  );
}
