// Reference integration of the Freemium gate. Paste your full Studio UI around this and keep the
// three gate hooks: duration slider, 4K / watermark controls, and the 402/429 handling in generate().
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';
import { usePaywall } from '../PaywallContext.jsx';
import { Wordmark } from '../Brand.jsx';
import { generateVideo, getJob, openBillingPortal } from '../api.js';

export default function Studio() {
  const { user, paid, limits, isAnonymous, logout } = useAuth();
  const openPaywall = usePaywall();

  const [file, setFile] = useState(null);
  const [script, setScript] = useState('');
  const [duration, setDuration] = useState(limits.maxSec);
  const [resolution, setResolution] = useState('1080p');
  const [job, setJob] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const justPaid = new URLSearchParams(window.location.search).get('checkout') === 'success' && !paid;

  // ── client-side gates: show the paywall the moment a free user reaches for a paid feature ──
  const onDuration = (v) => {
    if (v > limits.maxSec) { openPaywall('duration'); setDuration(limits.maxSec); } else setDuration(v);
  };
  const onResolution = (r) => {
    if (r === '4k' && !limits.allow4k) return openPaywall('resolution');
    setResolution(r);
  };

  async function generate() {
    if (!file) return setError('Choose a base video first.');
    setBusy(true); setError(''); setJob(null);
    const fd = new FormData();
    fd.append('baseVideo', file);
    fd.append('script', script);
    fd.append('maxDuration', String(duration));
    fd.append('resolution', resolution);
    // (also append logo, brollClips, audioPreference, voiceId, logoPosition, bRollDensity ... from your controls)
    try {
      const { jobId } = await generateVideo(fd);
      let j;
      do {
        await new Promise((r) => setTimeout(r, 1500));
        j = await getJob(jobId); // { status, stage, progress, outputUrl, watermarked, error }
        setJob(j);               // → drive your 5-step progress bar from j.stage / j.progress
      } while (j.status === 'queued' || j.status === 'processing');
      if (j.status === 'failed') setError(j.error);
    } catch (err) {
      // Server-side gate responses → open the Stripe paywall instead of showing a raw error
      if (err.code === 'PAYWALL_REQUIRED') openPaywall(err.reasons?.[0]);
      else if (err.code === 'DAILY_LIMIT') openPaywall('daily');
      else setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-5 p-6">
      <header className="flex items-center justify-between">
        <Wordmark className="text-lg" />
        <div className="flex items-center gap-3 text-sm text-slate-400">
          <span className={`rounded-full px-2.5 py-1 text-xs ${paid ? 'bg-indigo-500/20 text-indigo-200' : 'bg-slate-700 text-slate-300'}`}>
            {paid ? 'Pro' : 'Free · 7s preview'}
          </span>
          {isAnonymous ? <Link to="/login" className="hover:text-slate-200">Sign in</Link>
                       : <button onClick={logout} className="hover:text-slate-200">Sign out ({user.email})</button>}
        </div>
      </header>

      {justPaid && <p className="rounded-lg bg-emerald-500/10 p-3 text-sm text-emerald-300">Payment received — activating your plan…</p>}

      <section className="space-y-4 rounded-2xl border border-slate-700/50 bg-slate-800/40 p-5">
        <input type="file" accept="video/mp4,video/webm,video/quicktime" onChange={(e) => setFile(e.target.files[0])} className="text-sm" />
        <textarea value={script} onChange={(e) => setScript(e.target.value)} rows={3} placeholder="Topic or script…"
          className="w-full rounded-lg border border-slate-700 bg-slate-900/60 p-3 text-sm outline-none focus:border-indigo-400" />

        <label className="block text-sm">
          Duration: <b>{duration}s</b> {!paid && <span className="text-xs text-indigo-300">🔒 up to 2 min with Pro</span>}
          <input type="range" min="5" max="120" value={duration} onChange={(e) => onDuration(Number(e.target.value))} className="mt-1 w-full accent-indigo-400" />
        </label>

        <div className="flex flex-wrap gap-2 text-sm">
          {['1080p', '4k'].map((r) => (
            <button key={r} onClick={() => onResolution(r)}
              className={`rounded-lg border px-3 py-1.5 ${resolution === r ? 'border-indigo-400 bg-indigo-500/15 text-indigo-200' : 'border-slate-600 text-slate-400'}`}>
              {r.toUpperCase()}{r === '4k' && !paid && ' 🔒'}
            </button>
          ))}
          {!paid && <button onClick={() => openPaywall('watermark')} className="rounded-lg border border-slate-600 px-3 py-1.5 text-slate-400">Remove watermark 🔒</button>}
          {paid && <button onClick={openBillingPortal} className="rounded-lg border border-slate-600 px-3 py-1.5 text-slate-400">Manage billing</button>}
        </div>

        <button onClick={generate} disabled={busy}
          className="w-full rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 py-3 font-bold text-white disabled:opacity-60">
          {busy ? `Rendering… ${job?.progress ?? 0}%` : '✨ Generate Video'}
        </button>
        {error && <p className="text-sm text-red-300">{error}</p>}
      </section>

      {job?.status === 'completed' && (
        <section className="space-y-3 rounded-2xl border border-slate-700/50 bg-slate-800/40 p-5">
          <video src={job.outputUrl} controls className="w-full rounded-xl" />
          {/* Downloads are open to EVERYONE, including the watermarked 7-second preview. */}
          <a href={job.outputUrl} download className="block rounded-lg bg-slate-200 py-2.5 text-center font-semibold text-slate-900">⬇ Download MP4</a>
          {job.watermarked && (
            <button onClick={() => openPaywall('watermark')}
              className="w-full rounded-lg bg-gradient-to-r from-indigo-500 to-violet-500 py-2.5 font-semibold text-white">
              Unlock Full 2-Min Video &amp; Remove Watermark
            </button>
          )}
        </section>
      )}
    </div>
  );
}
